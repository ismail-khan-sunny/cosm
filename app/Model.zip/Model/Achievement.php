<?php
App::uses('AppModel', 'Model');
/**
 * Achievement Model
 *
 */
class Achievement extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'title';

}
