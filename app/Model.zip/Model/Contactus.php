<?php
App::uses('AppModel', 'Model');
/**
 * Contactus Model
 *
 */
class Contactus extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'title';

}
