<?php
App::uses('AppModel', 'Model');
/**
 * PositionApply Model
 *
 */
class PositionApply extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'title';

}
